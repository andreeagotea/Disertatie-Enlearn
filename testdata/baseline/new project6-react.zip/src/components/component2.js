import React from 'react'

import PropTypes from 'prop-types'

import projectStyles from '../style.module.css'
import styles from './component2.module.css'

const Component2 = (props) => {
  return (
    <div className={` ${styles['container']} ${styles[props.rootClassName]} `}>
      <button className={projectStyles['thqButton']}>{props.button}</button>
      <span>{props.text}</span>
    </div>
  )
}

Component2.defaultProps = {
  button: 'Button',
  text: 'Text',
  rootClassName: '',
}

Component2.propTypes = {
  button: PropTypes.string,
  text: PropTypes.string,
  rootClassName: PropTypes.string,
}

export default Component2
