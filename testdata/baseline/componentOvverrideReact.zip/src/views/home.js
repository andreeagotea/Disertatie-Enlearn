import React from 'react'

import { Helmet } from 'react-helmet'

import Component2 from '../components/component2'
import styles from './home.module.css'

const Home = () => {
  return (
    <div className={styles['container']}>
      <Helmet>
        <title>New Project44</title>
        <meta property="og:title" content="New Project44" />
      </Helmet>
      <Component2
        text="Text_Comp3_Ovverrides_Comp2"
        button="Button_Comp3_Ovverrides_Comp2"
        rootClassName="rootClassName"
      ></Component2>
      <Component2
        text="Text_Comp4_Ovverrides_Comp2"
        button="Button_Comp4_Ovverrides_Comp2"
        rootClassName="rootClassName1"
      ></Component2>
      <Component2
        text="Text_Comp5_Ovverrides_Comp2"
        button="Button_Comp5_Ovverrides_Comp2"
        rootClassName="rootClassName2"
      ></Component2>
    </div>
  )
}

export default Home
